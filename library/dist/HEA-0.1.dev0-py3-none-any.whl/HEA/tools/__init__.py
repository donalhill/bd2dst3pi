from .assertion import is_list_tuple

from .da import el_to_list, list_included, show_dictionnary

from .serial import dump_pickle, dump_json, retrieve_pickle, retrieve_json

from .string import list_into_string, add_text
